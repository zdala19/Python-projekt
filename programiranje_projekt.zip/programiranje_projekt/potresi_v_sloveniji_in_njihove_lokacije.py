from mpl_toolkits.basemap import Basemap
import numpy as np
import matplotlib.pyplot as plt

m = Basemap(width = 300000, height = 200000,
            resolution='i',projection='tmerc',lon_0=14.81,lat_0=46.12)

m.drawcoastlines()
m.drawcountries()
m.fillcontinents(color='moccasin',lake_color='skyblue')

m.drawmapboundary(fill_color='skyblue')
plt.title("Zemljevid Slovenije")

longitude = []
latitude = []
magnitude = []

with open('potresi_slo.txt', 'r') as f:
    f.readline()
    for vrstica in f:
        vrstica = vrstica.split('   |   ')
        magnitude.append(float(vrstica[2]))
        longitude.append(vrstica[4])
        latitude.append(vrstica[5])
        
lons = []
for i in longitude:
    koordinata = i.split('\xa0')
    if koordinata[1] == 'W':
        koordinata[0] = - float(koordinata[0])
    lons.append(float(koordinata[0]))

lats = []
for i in latitude:
    koordinata = i.split('\xa0')
    lats.append(float(koordinata[0]))

x,y = m(lons, lats)
m.scatter(x,y, marker='o', color = 'palevioletred')
plt.show()






