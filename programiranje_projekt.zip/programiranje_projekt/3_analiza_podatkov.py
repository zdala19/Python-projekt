#izpis podatkov iz datoteke za obdelavo ===================================================================================================
potresi = []
magnitude = []
drzave = []

with open('potresi.txt', 'r') as f:
    f.readline() #prebere samo prvo vrstico ne naredi ničesar
    for vrstica in f:
        potres = vrstica.split('   |   ')
        potresi.append(potres)
        magnitude.append(float(potres[3]))
        drzave.append(potres[0])

evropske_drzave = []
povrsine = []
with open('drzave_in_velikosti.txt', 'r') as f:
    f.readline() #prebere samo prvo vrstico ne naredi ničesar
    for vrstica in f:
        razrez = vrstica.split('    | ')
        drzava = razrez[0]
        povrsina = razrez[1][:-1]
        evropske_drzave.append(drzava)
        povrsine.append(povrsina)

#ureditev povrsin v zapisu, da jih imamo v obliki brez vmesnih vejic 

povrsine_koncno = []
for povrsina in povrsine:
    if ',' in povrsina:
        stevilo = povrsina.split(',')
        st = ''
        for i in stevilo:
            st += i
        povrsine_koncno.append(st)
    else:
        povrsine_koncno.append(povrsina)


#povprecna magnituda potresov po evropi ====================================================================================================

sestevek = 0
stevilo_potresov = len(potresi)
for potres in potresi:
    sestevek += float(potres[3])

povprecje_eu = sestevek // stevilo_potresov
print('Povprečna magnituda potresov po Evropi v zadnjem mesecu je ' + str(povprecje_eu) +'.')


#povprečna magnituda, število potresov in vsota magnitud za vsako državo posebej ========================================================================================================

def analiza_potresov_po_drzavah(potresi, drzava):
    '''Funkcija vrne tabelo analize potrasov v posamezni drzavi v obliki
       [vsota_magnitud, st_potresov, povprecna_mag]'''
    vsota_magnitud = 0
    st_potresov = 0
    tab_potresov = []
    for potres in potresi:
        if drzava in potres[0]:
            st_potresov += 1
            vsota_magnitud += float(potres[3])
    if st_potresov != 0:
        povprecna_mag = vsota_magnitud / st_potresov
    else:
        povprecna_mag = 0
    return [vsota_magnitud, st_potresov, round(povprecna_mag, 2)]

#izpis povprecnih magnitud in stevilo potresov za vsako državo posebej v datoteko ======================================================================================================

povprecne_magnitude = []
stevilo_potresov = []
for drzava in evropske_drzave:
    stevilo_potresov.append(analiza_potresov_po_drzavah(potresi, drzava)[1])
    povprecne_magnitude.append(analiza_potresov_po_drzavah(potresi, drzava)[2])
    
    
with open('stevilo_in_povp_mag.txt', 'w') as f:
    f.write('DRZAVA           |  ŠTEVILO POTRESOV   |  POVPREČNA MAGNITUDA    ')
    f.write('\n')
    i = 0
    while i < len(povprecne_magnitude):
        f.write(evropske_drzave[i] + '    |    ' + str(stevilo_potresov[i]) + '    |    ' + str(povprecne_magnitude[i]))
        i += 1
        f.write('\n')
        
#funkcija ki za vse države izpiše koliko je povprečna magnituda v primerjavi z evropskim povprecjem================================================

def povprecje_drzav(tabela):
    for drzava in tabela:
        podatki = analiza_potresov_po_drzavah(potresi, drzava) 
        povprecje_drzave = podatki[2]
        if povprecje_drzave < povprecje_eu:
            print('Povprečna magnituda v državi ' + drzava + ' v zadnjem mesecu je ' + str(povprecje_drzave) +', kar je pod evropskim povprečjem.')
        elif povprecje_drzave > povprecje_eu:
            print('Povprečna magnituda v državi ' + drzava + ' v zadnjem mesecu je ' + str(povprecje_drzave) +', kar je nad evropskim povprečjem.')
        else:
            print('Povprečna magnituda v državi ' + drzava + ' v zadnjem mesecu je ' + str(povprecje_drzave) +', kar je tudi evropsko povprečje.')
            
povprecje_drzav(evropske_drzave)        

#analiza potresov glede na globino ===============================================================================================================

st_plitvih = 0
st_vmesnih = 0
st_globokih = 0
for potres in potresi:
    if int(potres[4].split('KM')[0]) < 70:
        st_plitvih += 1
    elif 70 < int(potres[4].split('KM')[0]) < 300:
        st_vmesnih += 1
    else:
        st_globokih += 1

#plitvi
if st_plitvih == 2:
    print('V zadnjem mesecu sta bila ' + str(st_plitvih) + ' plitka potresa.')
elif st_plitvih == 1:
    print('V zadnjem mesecu je bil ' + str(st_plitvih) + ' plitek potres.')
else:
    print('V zadnjem mesecu je bilo ' + str(st_plitvih) + ' plitkih potresov.')

#vmesni
if st_vmesnih == 2:
    print('V zadnjem mesecu sta bila ' + str(st_vmesnih) + ' vmesna potresa.')
elif st_vmesnih == 1:
    print('V zadnjem mesecu je bil ' + str(st_vmesnih) + ' vmesen potres.')
else:
    print('V zadnjem mesecu je bilo ' + str(st_vmesnih) + ' vmesnih potresov.')

#globoki
if st_globokih == 2:
    print('V zadnjem mesecu sta bila ' + str(st_globokih) + ' globoka potresa.')
elif st_globokih == 1:
    print('V zadnjem mesecu je bil ' + str(st_globokih) + ' globok potres.')
else:
    print('V zadnjem mesecu je bilo ' + str(st_globokih) + ' globokih potresov.')

#največja magnituda v evropi v zadnjem mesecu ==========================================================================================

index_naj_magn = magnitude.index(max(magnitude))
drzava_z_naj_magn = drzave[index_naj_magn]

print(drzava_z_naj_magn + ' je država, ki je v zadnjem mesecu imela največjo magnitudo in sicer ' + str(max(magnitude)) + '.' )

#država, ki je v zadnjem mesecu imela največ potresov na splošno ========================================================================

index_naj_potresov = stevilo_potresov.index(max(stevilo_potresov))
drzava_z_najvec_potresi = evropske_drzave[index_naj_potresov]

print('Država, ki je v zadnjem mescecu imela največ potresov je ' + drzava_z_najvec_potresi + '.')

#stevilo potresov na kvadratni kilometer => po evropskih drzavah ========================================================================

def potresi_na_km2():
    #stevilo potresov vsake drzave spravimo v skupno tabelo
    stevilo_potresov = []
    for drzava in evropske_drzave:
        st_potresov = analiza_potresov_po_drzavah(potresi, drzava)[1]
        stevilo_potresov.append(st_potresov)
    #izracun stevilo potresov na km2 za vsako drzavo posebej in zapis teh vrednosti v tabelo
    potresi_na_km2 = []
    i = 0
    while i < len(stevilo_potresov):
        pov_na_km2 = stevilo_potresov[i] / float(povrsine_koncno[i])
        potresi_na_km2.append(pov_na_km2)
        i += 1
    return potresi_na_km2

#indeks elementa, ki ima najvecjo razmerje st. potresov/povrsina

index = potresi_na_km2().index(max(potresi_na_km2()))

print(evropske_drzave[index] + ' je država, ki je v zadnjem mesecu imela največ potresov glede na njeno površino.')


#na kateri dan v zadnjem mesecu je bilo največ potresov======================================================================================
datumi = []
tab = dict()
vec_moznosti = []

for potres in potresi:
    datumi.append(potres[1])

for datum in datumi:
    kolikokrat = datumi.count(datum)
    tab[datum] = kolikokrat #datume zapišemo v slovar, ključ je število potresov na ta dan

najveckrat = max(tab.values()) #največje število potresov v enem dnevu

for datum in tab:
    if tab[datum] == najveckrat: #pogledamo, če se zgodi, da je enako št potresov na več datumov
        vec_moznosti.append(datum)

if len(vec_moznosti) == 1:
    print('V zadnjem mesecu je bilo največ potresov na dan ' + str(vec_moznosti[0]) + ' in sicer ' + str(najveckrat) + '.')
else:
    print('V zadnjem mesesecu je bilo največ potresov v dneh ' + ', '.join(vec_moznosti) + ' in sicer ' + str(najveckrat) + '.')


#napoved potresov za slovenijo ==================================================================================================================

potresi_slo = []
with open('potresi_slo.txt', 'r') as f:
    f.readline() #prebere samo prvo vrstico ne naredi ničesar
    for vrstica in f:
        potres = vrstica.split('    |    ')
        potresi_slo.append(potres)

#gremo cez tabelo in pogledamo koliko je razlike med časi med potresi
        
import datetime

def razlike(datum1, cas1, datum2, cas2):
    '''funkcija pove koliko je razlike v urah med zaporednima potresoma'''
    datum1 = [int(i) for i in datum1.split('-')[::-1]]
    datum2 = [int(i) for i in datum2.split('-')[::-1]]
    cas1 = [int(i) for i in cas1.split(':')]
    cas2 = [int(i) for i in cas2.split(':')]
    date1 = datetime.datetime(datum1[2], datum1[1], datum1[0], cas1[0], cas1[1], cas1[2])
    date2 = datetime.datetime(datum2[2], datum2[1], datum2[0], cas2[0], cas2[1], cas2[2])
    if date1 < date2:
       razlika = date2 - date1
    else:
       razlika = date1 - date2
    razlika_v_urah = razlika.total_seconds() / 3600
    return razlika_v_urah

#naredimo tabelo vseh razlik v casih med potresi v sloveniji
raz = []
i = 0
while i < len(potresi_slo):
    potres1 = potresi_slo[i]
    try:
        potres2 = potresi_slo[i + 1]
        razlika = razlike(potres1[0], potres1[1], potres2[0], potres2[1])
        raz.append(razlika)
    except: break
    i += 1

#izračun povprečnega časa med dvema potresoma v sloveniji
sestevek = sum(raz)
stevilo = len(raz)

povprecje_cas = sestevek / stevilo #v urah
sekunde = povprecje_cas * 3600 #povprecni cas v sekundah

#sekunde v minute
minute = int(sekunde // 60 )
ostanek_sekund = round(sekunde % 60)

#minute v ure
ure = int(minute // 60)
ostanek_minut = round(minute % 60)

#ure v dan
dan = int(ure // 24)
ostanek_ur = round(ure % 24)



#napoved potresa:

zadnji_cas = [int(i) for i in potresi_slo[-1][1].split(':')]
zadnji_datum = [int(i) for i in potresi_slo[-1][0].split('-')]
cas_zadnjega = datetime.datetime(zadnji_datum[0], zadnji_datum[1], zadnji_datum[2], zadnji_cas[0], zadnji_cas[1], zadnji_cas[2])
 
povprecna_razlika = datetime.timedelta(days = dan, hours = ostanek_ur, minutes = ostanek_minut, seconds = ostanek_sekund)
cas_naslednjega = cas_zadnjega + povprecna_razlika
cas_naslednjega = str(cas_naslednjega).split()

print('Naslednji potres v Sloveniji se bo zgodil ' + cas_naslednjega[0] + ' ob ' + cas_naslednjega[1] + ' uri z magnitudo ' + str(analiza_potresov_po_drzavah(potresi, 'SLOVENIA')[2]) + '.')

