
#grafični prikaz število potresov po državah

import plotly as py
import plotly.graph_objs as go

#obdelani podatki
drzave = []
stevilo = []
povp_magnitude = []

with open('stevilo_in_povp_mag.txt', 'r') as f:
    f.readline() #prebere samo prvo vrstico ne naredi ničesar
    for vrstica in f:
        vrstica = vrstica.split('   |   ')
        drzave.append(vrstica[0])
        stevilo.append(int(vrstica[1]))
        povp_magnitude.append(float(vrstica[2][:-1]))

#podatki zapisani v obliki slovarja
data = dict(type = 'choropleth',
            locations = drzave,
            locationmode = 'country names',
            colorscale= 'Burg',
            z=stevilo,
            colorbar = {'title':'Število potresov', 'len':300,'lenmode':'pixels' })

map = go.Figure(data=[data])
py.offline.plot(map)