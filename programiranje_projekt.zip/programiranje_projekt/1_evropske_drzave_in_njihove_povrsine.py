#evropske drzave in njene površine
import re
import requests


niz = requests.get('https://en.wikipedia.org/wiki/List_of_European_countries_by_area').text
tabela = niz.split('<h2><span class="mw-headline"')[1]
imena_drzav = re.findall('data-file-width=".*" data-file-height=".*" /></span>&#160;<a href="/wiki/.*" title=".*">.*</a>', tabela)
velikosti_drzav = re.findall('<td style="text-align:right;" data-sort-value=".*">.*\n</td>', tabela)
samo_velikosti_v_km = [velikost.split('"')[4] for velikost in velikosti_drzav[::2]]
velikosti_urejeno = [velikost.split('\n')[0] for velikost in samo_velikosti_v_km]


velikosti_koncno = [velikost.split('>')[1] for velikost in velikosti_urejeno]
imena_drzav_urejeno = [ime.split('"')[7] for ime in imena_drzav]

#ureditev seznama površin in držav zaradi napak v tabelah

velikosti_koncno[50] = '29,743' #realna velikost armenije
velikosti_koncno[49] = '9,251'
imena_drzav_urejeno[22] = 'Ireland'
imena_drzav_urejeno[31] = 'The Netherlands'
imena_drzav_urejeno[40] = 'Georgia'
imena_drzav_urejeno.insert(35, 'North Macedonia')

#drzave zapisane z velikimi crkami
imena_drzav_koncno = []
for drzava in imena_drzav_urejeno:
    drzava = drzava.upper()
    imena_drzav_koncno.append(drzava)

        
#zapis imen drzav in velikosti v datoteko       
with open('drzave_in_velikosti.txt', 'w') as f:
    f.write('DRZAVA    | VELIKOST        ')
    f.write('\n')
    i = 0
    while i < len(imena_drzav_koncno):
        drzava = imena_drzav_koncno[i]
        povrsina = velikosti_koncno[i]
        f.write(drzava + '    | ' + povrsina)
        i += 1
        f.write('\n')
    
    
