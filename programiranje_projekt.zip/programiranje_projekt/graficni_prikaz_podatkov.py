import matplotlib.pyplot as plt
import numpy as np


#drzave in povprecne magnitude + stevilo potresov potresov v zadnjem mesecu
drzave = []
stevilo = []
povp_magnitude = []

with open('stevilo_in_povp_mag.txt', 'r') as f:
    f.readline() #prebere samo prvo vrstico ne naredi ničesar
    for vrstica in f:
        vrstica = vrstica.split('   |   ')
        drzave.append(vrstica[0])
        stevilo.append(int(vrstica[1]))
        povp_magnitude.append(float(vrstica[2][:-1]))

longitude = []
latitude = []
location = []
magnitude = []
    
with open('potresi.txt', 'r') as f:
    f.readline()
    for vrstica in f:
        vrstica = vrstica.split('   |   ')
        location.append(vrstica[0])
        magnitude.append(vrstica[3])
        longitude.append(vrstica[5])
        latitude.append(vrstica[6])

#iz tabel odtsranimo tiste države, ki nimajo potresov
drzave_novo = []
stevilo_novo = []
povp_magnitude_novo = []
i = 0
while i < len(stevilo):
    if stevilo[i] != 0:
        stevilo_novo.append(stevilo[i])
        drzave_novo.append(drzave[i])
        povp_magnitude_novo.append(povp_magnitude[i])
    i = i+1

height = stevilo_novo
bars = drzave_novo
y_pos = np.arange(len(bars))

#naredi horizontalne črte
plt.barh(y_pos, height, color = 'palevioletred')
 
#naredi imena na x osi
plt.yticks(y_pos, bars)

#imeni osi 
plt.xlabel('Št. potresov')
plt.ylabel('Država')

#naslov grafa
plt.title('ŠTEVILO POTRESOV PO DRŽAVAH')
#narišemo graf koliko je bilo potresov po državah
plt.show()

#Sedaj narišemo še grafikon
j = povp_magnitude_novo
b = drzave_novo
y_pos_2 = np.arange(len(b))
plt.barh(y_pos_2, j, color = 'palevioletred')
plt.yticks(y_pos_2, b)
plt.title('DRŽAVE IN POVPREČNE MAGNITUDE')
plt.xlabel('Povprečna magnituda')
plt.ylabel('Država')
plt.show()

#tortni diagram za potrese glede na globino
potresi = []
with open('potresi.txt', 'r') as f:
    f.readline() #prebere samo prvo vrstico ne naredi ničesar
    for vrstica in f:
        potres = vrstica.split('   |   ')
        potresi.append(potres)
        
st_plitvih = 0
st_vmesnih = 0
st_globokih = 0

for potres in potresi:
    if int(potres[4].split('KM')[0]) < 70:
        st_plitvih += 1
    elif 70 < int(potres[4].split('KM')[0]) < 300:
        st_vmesnih += 1
    else:
        st_globokih += 1

vsi = st_plitvih + st_vmesnih + st_globokih
plitvi = st_plitvih / vsi * 100
vmesni = st_vmesnih / vsi * 100
globoki = st_globokih / vsi * 100

y = np.array([plitvi,vmesni,globoki])
imena = ['Plitvi','Vmesni','Globoki']
barve = ["pink", "hotpink", "purple", "#4CAF50"]

plt.pie(y, labels = imena, colors = barve)
plt.legend(title = 'Potresi glede na globino:')
plt.show()