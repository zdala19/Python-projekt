from mpl_toolkits.basemap import Basemap
import numpy as np
import matplotlib.pyplot as plt

m = Basemap(width = 7513500, height = 5513500,
            resolution='i',projection='lcc',lon_0=13,lat_0=54)

m.drawcoastlines()
m.drawcountries()
m.fillcontinents(color='moccasin',lake_color='skyblue')

m.drawmapboundary(fill_color='skyblue')
plt.title("Lokacije potresov v Evropi v zadnjem mesecu")

longitude = []
latitude = []
location = []
magnitude = []
    
with open('potresi.txt', 'r') as f:
    f.readline()
    for vrstica in f:
        vrstica = vrstica.split('   |   ')
        location.append(vrstica[0])
        magnitude.append(float(vrstica[3]))
        longitude.append(vrstica[5])
        latitude.append(vrstica[6])
        
lons = []
for i in longitude:
    koordinata = i.split('\xa0')
    if koordinata[1] == 'W':
        koordinata[0] = - float(koordinata[0])
    lons.append(float(koordinata[0]))

lats = []
for i in latitude:
    koordinata = i.split('\xa0')
    lats.append(float(koordinata[0]))

x,y = m(lons, lats)
m.scatter(x,y, marker='.', color = 'palevioletred')
plt.show()



