
import requests
import re

#PODATKI =======================================================================================================================================
url = "https://global-earthquake-watch.p.rapidapi.com/month"

headers = {
    "X-RapidAPI-Host": "global-earthquake-watch.p.rapidapi.com",
    "X-RapidAPI-Key": "c1a140d124msh6187727a7ceb97bp1892d8jsn3b9d81e402db"
}

response = requests.request("GET", url, headers=headers)


tab = response.json()

#tabela evropskih drzav =======================================================================================================================
evropske_drzave = []

with open('drzave_in_velikosti.txt', 'r') as f:
    f.readline() #prebere samo prvo vrstico ne naredi ničesar
    for vrstica in f:
        razrez = vrstica.split('    | ')
        drzava = razrez[0]
        evropske_drzave.append(drzava)
        
#potresi po evropi ==============================================================================================================================
potresi_eu = []
for potres in tab:
    for drzava in evropske_drzave:
        if drzava in potres['location']:
            potresi_eu.append(potres)
    
#potresi po sloveniji ============================================================================================================================
potresi_slo = []
for potres in potresi_eu:
    if 'SLOVENIA' in potres['location'] :
        potresi_slo.append(potres)

#urejanje podatkov v obliko potres = [kraj, datum, magnituda, globina] ============================================================================

tab_potresov_eu = []
tab_potresov_slo = []

for i in potresi_eu:
    potres = []
    potres.append(i['location'])
    potres.append(i['date'])
    potres.append(i['time'])
    potres.append(i['magnitude'])
    potres.append(i['depth'])
    potres.append(i['longitude'])
    potres.append(i['latitude'])
    tab_potresov_eu.append(potres)

for i in potresi_slo:
    potres = []
    potres.append(i['date'])
    potres.append(i['time'])
    potres.append(i['magnitude'])
    potres.append(i['depth'])
    potres.append(i['longitude'])
    potres.append(i['latitude'])
    tab_potresov_slo.append(potres)

#POTRESI PO DRŽAVAH zapisani v datoteki================================================================================================================================
          
with open('potresi.txt', 'w') as f:
    f.write('DRZAVA           | DATUM      | ČAS     | MAGNITUDA     | GLOBINA     | LONGITUDE    | LATITUDE   ')
    f.write('\n')
    i = 0
    while i < len(tab_potresov_eu):
        potres = tab_potresov_eu[i]
        f.write(potres[0] + '   |   ' + potres[1] + '   |   ' + potres[2] + '   |   ' + potres[3] + '   |   ' + potres[4] + '   |   ' + potres[5] + '   |   ' + potres[6])
        i += 1
        f.write('\n')

#POTRESI PO SLOVENIJI zapisani v datoteki================================================================================================================================
          
with open('potresi_slo.txt', 'w') as f:
    f.write('    DATUM     |      ČAS       | MAGNITUDA |   GLOBINA     | LONGITUDE    | LATITUDE   ')
    f.write('\n')
    i = 0
    while i < len(tab_potresov_slo):
        potres = tab_potresov_slo[i]
        f.write(potres[0] + '    |    ' + potres[1] + '    |    ' + potres[2] + '    |    ' + potres[3] + '   |   ' + potres[4] + '   |   ' + potres[5])
        i += 1
        f.write('\n')



